# TootTally Leaderboard
> Version: 1.2.6

[TootTallyCore](https://toottally.com/)'s global leaderboard for custom songs and replay system.

**JOIN US IN THE [TOOTTALLY DISCORD!](https://discord.gg/9jQmVEDVTp)**

Still in active development, this mod's principal feature aims to be an alternative to the Steam Leaderboards for custom charts played using [TrombLoader](https://github.com/tc-mods/TrombLoader).

### Instructions

Charts being tracked can be searched in https://toottally.com/search/ or accessed programmatically in https://toottally.com/api/songs/
Charts can be manually uploaded in https://toottally.com/upload/

For more help, join the [Trombone Champ Modding Discord](https://discord.gg/KVzKRsbetJ) or the [TootTally Discord](https://discord.gg/9jQmVEDVTp)
